def preprocessor(data):
    preprocessed_data=scaler.transform(data)
    return preprocessed_data
